  //Slick Slider
  
  $(document).on('ready', function() {
    
    $(".center").slick({
      infinite: true,
      slidesToShow: 4,
      slidesToScroll: 1,
      responsive: [
        {
        breakpoint: 1024,
        settings: {
        slidesToShow: 2,
        slidesToScroll: 1
        }
        },
        {
        breakpoint: 800,
        settings: {
        slidesToShow: 2,
        slidesToScroll: 1
        }
        }
        
        ]
    });
  });


  
  $(".accordian1").click(function(){
    $("#collapseTwo").removeClass('show');
  });

  $(".accordian2").click(function(){
    $("#collapseOne").removeClass('show');
  });


  //specification popup
  $(".product-specification").click(function() {
    $(".popup").fadeIn(500);
  });
  $(".close").click(function() {
    $(".popup").fadeOut(500);
  });